# Countdown-Timer

![Alt text](pic1.png)

- Measurement of this project: "small"
- future date countdown timer
- Using HTML, CSS, JavaScript

Sample:
- https://uidesigndaily.com/posts/sketch-countdown-timer-day-876
